// Cloudflare Worker: trang cấp key + API kiểm tra key 24h.
// Bí mật cần đặt:  wrangler secret put SECRET   (chuỗi ngẫu nhiên dài)

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 32 ký tự, bỏ I/O/0/1
const KEY_RE = /^FF-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

function randomString(n) {
  const b = new Uint8Array(n);
  crypto.getRandomValues(b);
  return Array.from(b, (x) => ALPHABET[x % ALPHABET.length]).join("");
}
const makeKey = () => `FF-${randomString(4)}-${randomString(4)}-${randomString(4)}`;

async function hmac(env, msg) {
  const k = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(env.SECRET),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const s = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(s), (b) => b.toString(16).padStart(2, "0")).join("");
}

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

async function readJson(req) {
  try { return await req.json(); } catch { return {}; }
}

const minWait = (env) => parseInt(env.MIN_WAIT_SECONDS || "20", 10);
const keyHours = (env) => parseInt(env.KEY_HOURS || "24", 10);

// Bước 1: cấp token có chữ ký, ghi lại thời điểm bắt đầu (không ghi KV).
async function start(env) {
  if (!env.SECRET) return json({ error: "server_not_configured" }, 500);
  const t = Date.now();
  const nonce = randomString(12);
  const sig = await hmac(env, `${t}.${nonce}`);
  return json({ token: `${t}.${nonce}.${sig}`, wait: minWait(env) });
}

// Bước 2: đủ thời gian chờ thì đổi token lấy key (mỗi token dùng 1 lần).
async function claim(req, env) {
  const { token } = await readJson(req);
  const parts = String(token || "").split(".");
  if (parts.length !== 3) return json({ error: "bad_token" }, 400);
  const [t, nonce, sig] = parts;
  if (!safeEqual(sig, await hmac(env, `${t}.${nonce}`))) return json({ error: "bad_token" }, 400);

  const age = Date.now() - Number(t);
  if (!(age >= minWait(env) * 1000)) {
    return json({ error: "too_early", retryAfter: Math.ceil((minWait(env) * 1000 - age) / 1000) }, 425);
  }
  if (age > 30 * 60 * 1000) return json({ error: "token_expired" }, 400);
  if (await env.KEYS.get(`u:${nonce}`)) return json({ error: "used" }, 409);
  await env.KEYS.put(`u:${nonce}`, "1", { expirationTtl: 3600 });

  const key = makeKey();
  const now = Date.now();
  const exp = now + keyHours(env) * 3600 * 1000;
  await env.KEYS.put(`k:${key}`, JSON.stringify({ issued: now, exp, device: null }), {
    expirationTtl: keyHours(env) * 3600 + 60,
  });
  return json({ key, expiresAt: exp });
}

// App gọi: kiểm tra key, gắn key vào thiết bị ở lần dùng đầu.
async function verify(req, env) {
  const { key, device } = await readJson(req);
  const k = String(key || "").trim().toUpperCase();
  const d = String(device || "").slice(0, 64);
  if (!KEY_RE.test(k) || !d) return json({ valid: false, reason: "bad_request" });

  const raw = await env.KEYS.get(`k:${k}`);
  if (!raw) return json({ valid: false, reason: "not_found" });
  const rec = JSON.parse(raw);
  const now = Date.now();
  if (now >= rec.exp) return json({ valid: false, reason: "expired" });

  if (!rec.device) {
    rec.device = d;
    await env.KEYS.put(`k:${k}`, JSON.stringify(rec), {
      expirationTtl: Math.max(60, Math.ceil((rec.exp - now) / 1000) + 60),
    });
  } else if (rec.device !== d) {
    return json({ valid: false, reason: "other_device" });
  }
  return json({ valid: true, expiresAt: rec.exp });
}

function page(env) {
  const html = `<!doctype html>
<html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nhận key Res Downscale</title>
${env.MONETAG_SNIPPET || ""}
<style>
body{font-family:system-ui,sans-serif;max-width:420px;margin:0 auto;padding:24px;text-align:center}
button{font-size:18px;padding:12px 24px;border-radius:10px;border:0;background:#2563eb;color:#fff}
button:disabled{background:#9ca3af}
#key{font-size:24px;font-weight:700;letter-spacing:1px;margin:16px 0;user-select:all}
.small{color:#6b7280;font-size:14px}
</style></head><body>
<h2>Nhận key 24 giờ</h2>
<p class="small">Quảng cáo trên trang giúp app luôn miễn phí. Bạn chỉ cần chờ hết thời gian, không cần bấm vào quảng cáo.</p>
<p id="msg">Đang chuẩn bị...</p>
<button id="btn" disabled>Nhận key</button>
<div id="out" style="display:none">
  <div id="key"></div>
  <button id="copy">Sao chép</button>
  <p class="small" id="exp"></p>
</div>
<script>
var token=null, wait=20, left=0;
function $(i){return document.getElementById(i)}
function tick(){
  if(left>0){ $("msg").textContent="Vui lòng chờ "+left+" giây..."; left--; setTimeout(tick,1000); }
  else { $("msg").textContent="Sẵn sàng!"; $("btn").disabled=false; }
}
fetch("/api/start",{method:"POST"}).then(function(r){return r.json()}).then(function(j){
  if(!j.token){ $("msg").textContent="Máy chủ chưa sẵn sàng, thử lại sau."; return; }
  token=j.token; wait=j.wait; left=wait+1; tick();
}).catch(function(){ $("msg").textContent="Lỗi mạng, hãy tải lại trang."; });
$("btn").onclick=function(){
  $("btn").disabled=true;
  fetch("/api/claim",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({token:token})})
  .then(function(r){return r.json()}).then(function(j){
    if(j.key){
      $("key").textContent=j.key; $("out").style.display="block"; $("btn").style.display="none";
      $("msg").textContent="Key của bạn:";
      $("exp").textContent="Hết hạn lúc "+new Date(j.expiresAt).toLocaleString("vi-VN")+". Key chỉ dùng cho 1 thiết bị.";
    } else if(j.error==="too_early"){
      left=(j.retryAfter||2)+1; tick();
    } else { $("msg").textContent="Không nhận được key ("+(j.error||"lỗi")+"). Hãy tải lại trang."; }
  }).catch(function(){ $("msg").textContent="Lỗi mạng, thử lại."; $("btn").disabled=false; });
};
$("copy").onclick=function(){
  var t=$("key").textContent;
  if(navigator.clipboard){ navigator.clipboard.writeText(t); $("copy").textContent="Đã chép"; }
};
</script></body></html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}

export default {
  async fetch(req, env) {
    const { pathname } = new URL(req.url);
    if (req.method === "GET" && pathname === "/") return page(env);
    if (req.method === "POST" && pathname === "/api/start") return start(env);
    if (req.method === "POST" && pathname === "/api/claim") return claim(req, env);
    if (req.method === "POST" && pathname === "/api/verify") return verify(req, env);
    return new Response("Not found", { status: 404 });
  },
};
