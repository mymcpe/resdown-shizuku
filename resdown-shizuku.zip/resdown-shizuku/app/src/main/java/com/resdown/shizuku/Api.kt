package com.resdown.shizuku

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    data class Result(val valid: Boolean, val reason: String, val expiresAt: Long)

    /** Gọi trên luồng nền. Ném exception nếu không kết nối được. */
    fun verify(key: String, device: String): Result {
        val c = URL(Config.API_BASE + "/api/verify").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use {
                it.write(JSONObject().put("key", key).put("device", device).toString().toByteArray())
            }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val j = JSONObject(stream.bufferedReader().readText())
            return Result(j.optBoolean("valid"), j.optString("reason"), j.optLong("expiresAt"))
        } finally {
            c.disconnect()
        }
    }
}
