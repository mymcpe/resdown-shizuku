package com.resdown.shizuku

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var spinner: Spinner
    private lateinit var factorInput: EditText
    private lateinit var pkgInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var licenseView: TextView
    private val prefs by lazy { getSharedPreferences("lic", MODE_PRIVATE) }
    private var apps: List<Pair<String, String>> = emptyList()

    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val permListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadApps()
        if (Config.REQUIRE_KEY) showLicense()
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
            root.addView(this, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        fun label(text: String) = TextView(this).apply {
            this.text = text
            setPadding(0, pad / 2, 0, 0)
            root.addView(this)
        }

        statusView = TextView(this).apply { textSize = 16f }
        root.addView(statusView)
        btn("Cấp quyền Shizuku") { requestPerm() }

        if (Config.REQUIRE_KEY) {
            label("Key (hết hạn sau 24 giờ)")
            keyInput = EditText(this).apply { hint = "FF-XXXX-XXXX-XXXX"; setSingleLine() }
            root.addView(keyInput, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            btn("Lấy key (mở trình duyệt)") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Config.API_BASE)))
            }
            btn("Kích hoạt key") { activate() }
            licenseView = TextView(this)
            root.addView(licenseView)
        }

        label("Chọn game (tự lọc Free Fire)")
        spinner = Spinner(this)
        root.addView(spinner, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        label("Hoặc nhập tay package (để trống = dùng game đã chọn ở trên)")
        pkgInput = EditText(this).apply { hint = "vd: com.dts.freefireth"; setSingleLine() }
        root.addView(pkgInput, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        label("Hệ số độ phân giải (0.3 - 1.0, ví dụ 0.5 = 50%)")
        factorInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("0.5")
        }
        root.addView(factorInput, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        btn("Áp dụng (Cách 1, lỗi thì Cách 2)") { apply(allowFallback = true) }
        btn("Chỉ Cách 2 (đổi cả màn hình)") { applyScreenOnly() }
        btn("Khôi phục tất cả") { reset() }

        logView = TextView(this).apply { setTextIsSelectable(true); setPadding(0, pad, 0, 0) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val ff = all.filter {
            it.second.contains("freefire", ignoreCase = true) ||
                it.first.replace(" ", "").contains("freefire", ignoreCase = true)
        }
        apps = if (ff.isNotEmpty()) ff else all
        if (ff.isEmpty()) log("Không thấy Free Fire trong máy, đang hiện tất cả app. Có thể nhập tay package.")
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            apps.map { "${it.first} (${it.second})" }
        )
    }

    private fun refresh() {
        statusView.text = when {
            !Shizuku.pingBinder() -> "Shizuku: chưa chạy. Mở app Shizuku và khởi động trước."
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                "Shizuku: đang chạy, chưa cấp quyền cho app này."
            else -> "Shizuku: sẵn sàng (Android API ${Build.VERSION.SDK_INT})"
        }
    }

    private fun ready(): Boolean {
        if (!Shizuku.pingBinder()) { toast("Hãy khởi động Shizuku trước"); return false }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            toast("Chưa cấp quyền Shizuku"); return false
        }
        return true
    }

    private fun requestPerm() {
        if (!Shizuku.pingBinder()) { toast("Hãy khởi động Shizuku trước"); return }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { refresh(); return }
        Shizuku.requestPermission(100)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun log(s: String) = runOnUiThread { logView.append(s + "\n") }
    private fun bg(block: () -> Unit) = Thread {
        try { block() } catch (e: Throwable) { log("Lỗi: ${e.message ?: e}") }
    }.start()

    /** Package nhập tay ưu tiên; nếu trống thì lấy game đang chọn. */
    private fun targetPackage(): String? {
        val manual = pkgInput.text.toString().trim()
        if (manual.isNotEmpty()) return manual
        val idx = spinner.selectedItemPosition
        return apps.getOrNull(idx)?.second
    }

    // ---------- Key / license ----------
    private fun deviceId(): String =
        Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    private fun fmt(ms: Long): String =
        SimpleDateFormat("HH:mm dd/MM", Locale.getDefault()).format(Date(ms))

    private fun reasonText(r: String): String = when (r) {
        "not_found" -> "Key sai hoặc đã hết hạn."
        "expired" -> "Key đã hết hạn, hãy lấy key mới."
        "other_device" -> "Key này đã gắn với thiết bị khác."
        "bad_request" -> "Key không đúng định dạng."
        else -> "Key không hợp lệ ($r)."
    }

    private fun showLicense() {
        val exp = prefs.getLong("exp", 0)
        licenseView.text =
            if (exp > System.currentTimeMillis()) "Key còn hạn đến ${fmt(exp)}" else "Chưa kích hoạt key"
    }

    private fun activate() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) { toast("Hãy nhập key"); return }
        bg {
            val r = try {
                Api.verify(key, deviceId())
            } catch (e: Exception) {
                log("Không kết nối được máy chủ key."); return@bg
            }
            if (r.valid) {
                prefs.edit().putString("key", key).putLong("exp", r.expiresAt).apply()
                log("Kích hoạt thành công, hạn đến ${fmt(r.expiresAt)}.")
                runOnUiThread { showLicense() }
            } else {
                log(reasonText(r.reason))
            }
        }
    }

    /** Chỉ chặn nút Áp dụng. Khôi phục luôn dùng được, không cần key. */
    private fun checkLicense(): Boolean {
        if (!Config.REQUIRE_KEY) return true
        val key = prefs.getString("key", null)
        if (key.isNullOrBlank()) {
            log("Chưa có key. Bấm \"Lấy key\", rồi nhập và kích hoạt."); return false
        }
        val r = try {
            Api.verify(key, deviceId())
        } catch (e: Exception) {
            log("Không kết nối được máy chủ key. Cần internet để áp dụng."); return false
        }
        if (!r.valid) {
            prefs.edit().clear().apply()
            log(reasonText(r.reason))
            runOnUiThread { showLicense() }
            return false
        }
        return true
    }

    private fun factor(): Double =
        (factorInput.text.toString().toDoubleOrNull() ?: 0.5).coerceIn(0.3, 1.0)

    // ---------- Actions ----------
    private fun apply(allowFallback: Boolean) {
        if (!ready()) return
        val pkg = targetPackage() ?: run { toast("Chưa chọn game"); return }
        val f = factor()
        bg {
            if (!checkLicense()) return@bg
            if (!method1(pkg, f) && allowFallback) method2(f)
        }
    }

    private fun applyScreenOnly() {
        if (!ready()) return
        val f = factor()
        bg {
            if (!checkLicense()) return@bg
            method2(f)
        }
    }

    private fun reset() {
        if (!ready()) return
        val pkg = targetPackage()
        bg {
            if (pkg != null) Shell.run("cmd", "game", "reset", pkg)
            resetScreen()
            log("Đã khôi phục.")
        }
    }

    /** Cách 1 (chính): Game Mode downscale riêng cho 1 game, Android 12+. */
    private fun method1(pkg: String, f: Double): Boolean {
        if (Build.VERSION.SDK_INT < 31) { log("[Cách 1] Android < 12, không hỗ trợ."); return false }
        val (_, out) = Shell.run("cmd", "game", "set", "--mode", "performance", "--downscale", f.toString(), pkg)
        if (Regex("error|exception|unknown|usage|not found", RegexOption.IGNORE_CASE).containsMatchIn(out)) {
            log("[Cách 1] Thất bại: $out"); return false
        }
        log("[Cách 1] Đã áp dụng $f cho $pkg. Tắt hẳn game rồi mở lại.")
        return true
    }

    /** Cách 2 (dự phòng): wm size + wm density cho cả màn hình, có tự khôi phục. */
    private fun method2(f: Double) {
        val sizeOut = Shell.run("wm", "size").second
        val densOut = Shell.run("wm", "density").second
        val size = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(sizeOut)
        val dens = Regex("Physical density:\\s*(\\d+)").find(densOut)
        if (size == null || dens == null) { log("[Cách 2] Không đọc được size/density gốc."); return }
        val w = size.groupValues[1].toInt()
        val h = size.groupValues[2].toInt()
        val d = dens.groupValues[1].toInt()
        val nw = (w * f / 2).toInt() * 2
        val nh = (h * f / 2).toInt() * 2
        val nd = (d * f).toInt()
        log("[Cách 2] ${w}x$h/$d -> ${nw}x$nh/$nd (toàn màn hình)")
        Shell.run("wm", "size", "${nw}x$nh")
        Shell.run("wm", "density", nd.toString())
        runOnUiThread { showKeepDialog() }
    }

    private fun resetScreen() {
        Shell.run("wm", "size", "reset")
        Shell.run("wm", "density", "reset")
    }

    private fun showKeepDialog() {
        lateinit var dialog: AlertDialog
        val timer = object : CountDownTimer(15000, 1000) {
            override fun onTick(ms: Long) { dialog.setMessage("Tự khôi phục sau ${ms / 1000 + 1}s") }
            override fun onFinish() { dialog.dismiss(); bg { resetScreen(); log("Hết giờ, đã khôi phục.") } }
        }
        dialog = AlertDialog.Builder(this)
            .setTitle("Giữ cài đặt này?")
            .setMessage("Tự khôi phục sau 15s")
            .setCancelable(false)
            .setPositiveButton("Giữ") { _, _ -> timer.cancel(); log("Đã giữ. Bấm \"Khôi phục tất cả\" khi cần.") }
            .setNegativeButton("Khôi phục ngay") { _, _ -> timer.cancel(); bg { resetScreen(); log("Đã khôi phục.") } }
            .create()
        dialog.show()
        timer.start()
    }
}
