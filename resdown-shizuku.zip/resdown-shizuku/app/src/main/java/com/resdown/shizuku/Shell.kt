package com.resdown.shizuku

import rikka.shizuku.Shizuku
import java.lang.reflect.InvocationTargetException

/** Chạy lệnh với quyền shell (uid 2000) thông qua Shizuku. */
object Shell {
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        ).also { it.isAccessible = true }
    }

    fun run(vararg cmd: String): Pair<Int, String> {
        val p = try {
            newProcess.invoke(null, cmd as Array<String>, null, null) as Process
        } catch (e: InvocationTargetException) {
            throw e.targetException ?: e
        }
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to (out + err).trim()
    }
}
