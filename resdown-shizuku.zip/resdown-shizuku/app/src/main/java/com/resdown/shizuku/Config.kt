package com.resdown.shizuku

object Config {
    /** Đặt false để tắt yêu cầu key (dùng khi test). */
    const val REQUIRE_KEY = true

    /** Địa chỉ Worker sau khi deploy, ví dụ https://resdown-keys.ten-ban.workers.dev */
    const val API_BASE = "https://resdown-keys.YOUR-SUBDOMAIN.workers.dev"
}
