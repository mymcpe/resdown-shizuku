# resdown-shizuku

App Android giảm độ phân giải game, chạy bằng [Shizuku](https://shizuku.rikka.app/), không cần root, không cần máy tính (sau khi khởi động Shizuku).

- **Cách 1 (chính):** Game Mode downscale riêng từng game (`cmd game set --downscale`, Android 12+).
- **Cách 2 (dự phòng):** `wm size` + `wm density` cho cả màn hình. Có hộp thoại đếm ngược 15s, không bấm "Giữ" thì tự khôi phục.

Nút "Áp dụng" thử Cách 1 trước; nếu lỗi hoặc Android < 12 thì tự chuyển sang Cách 2.

## Build bằng GitHub Actions (không cần Android Studio)
1. Push repo này lên GitHub (nhánh `main`).
2. Vào tab **Actions** > workflow **Build APK** > chạy xong, tải artifact `resdown-shizuku-debug`.
3. Giải nén, cài `app-debug.apk` lên điện thoại.

Build local: cần JDK 17 + Android SDK, chạy `gradle assembleDebug`.

## Dùng
1. Cài Shizuku từ GitHub/Play Store, bật Gỡ lỗi không dây, khởi động Shizuku theo hướng dẫn trong app.
2. Mở Res Downscale > **Cấp quyền Shizuku**.
3. Chọn game (app tự lọc Free Fire; không thấy thì nhập tay package), nhập hệ số (0.5 = 50%), bấm **Áp dụng**.
4. Tắt hẳn game rồi mở lại. **Khôi phục tất cả** để trả về mặc định.

## Lưu ý
- Một số game không nhận downscale từ Game Mode (khi đó dùng Cách 2).
- Khởi động lại máy thì phải khởi động lại Shizuku (trừ khi có root).
- Hệ số < 0.5 có thể làm chữ rất mờ.

## License
MIT

---

# Hệ thống key 24 giờ (Monetag)

Luồng: người dùng bấm **Lấy key** > trang trên Cloudflare Worker có quảng cáo Monetag, chờ ~20s > nhận key `FF-XXXX-XXXX-XXXX` > nhập vào app > server kiểm tra. Key hết hạn sau 24h và gắn với 1 thiết bị ở lần dùng đầu. Nút **Khôi phục** luôn dùng được, không cần key.

## Cài server (`server/`)
```bash
cd server
npm i -g wrangler && wrangler login
wrangler kv namespace create KEYS     # copy id dán vào wrangler.toml
wrangler secret put SECRET            # nhập một chuỗi ngẫu nhiên dài
# dán mã quảng cáo Monetag vào MONETAG_SNIPPET trong wrangler.toml
wrangler deploy
```
Sau khi deploy bạn có địa chỉ `https://resdown-keys.<tên>.workers.dev`. Mở địa chỉ này trên trình duyệt để thử lấy key.

## Nối app với server
Sửa `app/src/main/java/com/resdown/shizuku/Config.kt`: đặt `API_BASE` thành địa chỉ Worker. Push lại để GitHub Actions build APK mới. Đặt `REQUIRE_KEY = false` nếu muốn test app mà không cần key.

## Lưu ý
- KV gói miễn phí giới hạn khoảng 1.000 lượt ghi/ngày; mỗi key tốn khoảng 3 lượt ghi, tức khoảng 300 key/ngày. Nhiều hơn thì cần gói trả phí của Cloudflare.
- Thời gian chờ chỉ làm khó người lấy key quá nhanh, không chứng minh quảng cáo đã được xem. Để chống bot, bạn có thể thêm Cloudflare Turnstile hoặc luật giới hạn tốc độ (Rate Limiting) cho domain.
- Monetag có thể yêu cầu xác minh site hoặc domain riêng; làm theo hướng dẫn trong dashboard của họ.
- Không ép hay dụ người dùng bấm quảng cáo, vì có thể bị coi là lưu lượng không hợp lệ.
- Phần kiểm tra key ở server; người giỏi vẫn có thể sửa APK để bỏ kiểm tra. Đây là giới hạn chung của app Android.
